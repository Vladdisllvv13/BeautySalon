﻿using BeautySalonApp.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BeautySalonApp.pages
{
    /// <summary>
    /// Логика взаимодействия для ClientServicePage.xaml
    /// </summary>
    public partial class ClientServicePage : Page
    {
        Client _currentClient = new Client();
        public ClientServicePage(Client client)
        {
            InitializeComponent();
            if (client != null)
            {
                _currentClient = client;
                
            }
            DataContext = _currentClient;
            Update();
        }
        public void Update()
        {
            TbClientInfo.Text = $"{_currentClient.FirstName} {_currentClient.LastName} {_currentClient.Patronymic}";
            if (_currentClient.ServiceList.Count > 0)
            {
                LViewService.ItemsSource = _currentClient.ServiceList;
            }
            else
            {
                LViewService.Visibility = Visibility.Hidden;
                spServiceInfo.Children.Clear();
                TextBlock tb = new TextBlock();
                tb.Text = "У данного клиента нет посещений";
                tb.FontSize = 22;
                tb.HorizontalAlignment = HorizontalAlignment.Center;
                tb.VerticalAlignment = VerticalAlignment.Center;
                spServiceInfo.Children.Add(tb);
            }
        }

        private void BtnDelService_Click(object sender, RoutedEventArgs e)
        {
            if (LViewService.SelectedItems.Count > 0)
            {
                if (MessageBox.Show($"Вы действительно хотите удалить {LViewService.SelectedItems.Count} посещение?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    try
                    {
                        StringBuilder errors = new StringBuilder();
                        var selected = LViewService.SelectedItems.Cast<ClientService>().ToArray();
                        int serviceCount = 0;
                        foreach (var item in selected)
                        {
                            BeautySalonEntities.GetContext().ClientService.Remove(BeautySalonEntities.GetContext().ClientService.Where(cs => cs.ServiceID == item.ID || cs.ClientID == _currentClient.ID).First());
                            BeautySalonEntities.GetContext().SaveChanges();
                            serviceCount++;

                        }
                        if (errors.Length > 0)
                        {
                            MessageBox.Show(errors.ToString());
                        }
                        if (serviceCount != 0)
                        {
                            MessageBox.Show($"Удалено сервисов: {serviceCount}", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        Update();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }

            }
            else
            {
                MessageBox.Show("Выберите сервис для удаления", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnRefrService_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (LViewService.SelectedItem != null)
                {
                    ClientService clientService = LViewService.SelectedItem as ClientService;
                    var service = BeautySalonEntities.GetContext().Service.Where(s => s.ID == clientService.ServiceID).First();
                    if (service != null) NavigationService.Navigate(new EditServicePage(service));
                }
                else
                {
                    MessageBox.Show("Выберите сервис для изменения", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Update();
        }
    }
}
