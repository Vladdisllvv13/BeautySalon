﻿using BeautySalonApp.model;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BeautySalonApp.pages
{
    /// <summary>
    /// Логика взаимодействия для EditServicePage.xaml
    /// </summary>
    public partial class EditServicePage : Page
    {
        ClientService clientService = new ClientService();
        Service _currentService = new Service(); 
        public EditServicePage(Service service)
        {
            InitializeComponent();
            if (service != null)
            {
                _currentService = service;
            }
            DataContext = _currentService;
        }

        private void btnEnterImage_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Filter = "Файлы изображений: (*.png,  *.jpg, *.jpeg) | *.png; *.jpg; *.jpeg";
                dlg.InitialDirectory = "BeautySalonApp\\images\\Услуги салона красоты";
                if(dlg.ShowDialog() == true)
                {
                    _currentService.MainImagePath = @"Услуги салона красоты\" + dlg.SafeFileName;
                    imgPhoto.Source = new BitmapImage(new Uri(dlg.FileName));
                }
                    
                BeautySalonEntities.GetContext().SaveChanges();
                MessageBox.Show("Фотография изменена");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelImage_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string defaultImagePath = (string)FindResource("defaultImage");
                if (!string.IsNullOrEmpty(defaultImagePath))
                {
                    BitmapImage defaultImage = new BitmapImage(new Uri(defaultImagePath));
                    imgPhoto.Source = defaultImage;
                }
                _currentService.MainImagePath = null;
                BeautySalonEntities.GetContext().SaveChanges();
                MessageBox.Show("Фотография удалена");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка");
            }
        }

        private void btnRefrSer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BeautySalonEntities.GetContext().SaveChanges();
                MessageBox.Show("Изменено");
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void TbTitleServ_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }

        private void TbDurationInSecondsServ_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }

        private void TbCostServ_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }

        private void TbDiscountServ_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }

        private void TbDescriptionServ_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }
    }

}
